# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/topics/items.html

from scrapy.item import Item, Field

class LeboncoinItem(Item):
    # define the fields for your item here like:
    # name = Field()
    id          = Field()
    name        = Field()
    photo       = Field()
    url         = Field()
    category    = Field()
    search      = Field()
    price       = Field()
    placement   = Field()
    #pass
