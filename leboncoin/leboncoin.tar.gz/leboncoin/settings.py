# Scrapy settings for leboncoin project
#
# For simplicity, this file contains only the most important settings by
# default. All the other settings are documented here:
#
#     http://doc.scrapy.org/topics/settings.html
#

BOT_NAME = 'leboncoin'
BOT_VERSION = '1.0'

SPIDER_MODULES = ['leboncoin.spiders']
NEWSPIDER_MODULE = 'leboncoin.spiders'
USER_AGENT = '%s/%s' % (BOT_NAME, BOT_VERSION)

BASE_DIR = '/tmp'

DOWNLOADER_MIDDLEWARE = {
    'spider.middlewares.RetryChangeProxyMiddleware': 600,
}

ITEM_PIPELINES = ['leboncoin.pipelines.MongoDBPipeline',]

MONGODB_SERVER = "localhost"
MONGODB_PORT = 27017
MONGODB_DB = "leboncoin"
MONGODB_COLLECTION = "adds"


LBC_SEARCHES    = ['industriel','loft','bois metal','porte manteau','vintage', 'meuble hifi', 'meuble tv']
LBC_CATEGORIES  = ['ameublement','decoration','arts_de_la_table']
LBC_DEPTH       = 15

# > db.adds.aggregate({$group: { _id: {search: "$search", category: "$category"}  }   })
# > db.adds.distinct("search")


